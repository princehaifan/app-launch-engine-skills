---
name: mvp-architect
description: >
  Step 2 of 6 in the App Launch Engine Pipeline. Turns the approved
  problem_report.md into an implementation-ready product spec: MVP scope,
  cut list, user flows, screen designs, tech stack decision, data model,
  licensing approach, and a task-by-task build plan. Output gates app
  building. Saves as product_spec.md.
---

# MVP Architect

A spec is a promise about what will NOT be built.
Your job is to shrink the idea until one person can finish it in
1-2 weeks, and then make every remaining decision so the builder
never has to stop and ask.
Save as `product_spec.md`.

---

## The Core Constraint

```
THE MVP RULE:
  Ship ONE core job done well. Not five jobs done badly.
  Every feature must pass: "Without this, would a buyer refuse
  to pay?" If no, it goes on the CUT LIST for v1.1.

THE FINISH RULE:
  A desktop app that looks unfinished does not sell.
  Polish budget: empty states, error messages, drag-and-drop,
  keyboard shortcuts, dark mode, and a sensible default window size.
```

---

## Step 1 - Product Identity

```
NAME: [short, memorable, checkable - search that the name and
       .com / Gumroad slug are not taken]
TAGLINE: [under 8 words, result-focused]
PLATFORMS: Windows first (default). Add macOS only if the user
           owns a Mac to test and sign on.
PRICE: [from problem_report.md]
LICENSING: one-time purchase + license key (see Step 5)
```

---

## Step 2 - Scope: Must / Should / Cut

```
MUST (v1.0 - needed to sell):
  1. [feature - one line, testable]
  2. ...
  (max 5)

SHOULD (only if time remains):
  ...

CUT LIST (explicitly NOT in v1.0):
  - accounts / cloud sync / auto-update server / plugins / themes
  - anything needing a backend
  - [idea-specific cuts]

ACCEPTANCE CRITERIA (per MUST feature):
  Given [state], when [action], then [observable result].
```

---

## Step 3 - Tech Stack Decision

```
DECIDE, DO NOT LIST OPTIONS. Default choice:

  DEFAULT: Electron + Vite + vanilla TypeScript (or React) +
           electron-builder -> NSIS installer (.exe)
    Why: one codebase, huge ecosystem, easiest packaging,
         easiest UI polish with HTML/CSS.
    Cost: ~100MB+ installer. Acceptable for v1.

  CHOOSE INSTEAD when the problem demands it:
    - Tauri (Rust + web UI): small installer, but needs Rust toolchain
    - Python + PySide6/CustomTkinter + PyInstaller: when the core
      logic is data/ML/file processing in Python
    - .NET (WPF/WinUI): Windows-only deep OS integration

  STATE: chosen stack, the reason in one sentence, and the exact
  versions to pin. Check current stable versions before pinning.

STORAGE: local JSON or SQLite in the OS app-data folder.
         Never write into the install directory.
PRIVACY: no telemetry by default. State this; it is a selling point.
```

---

## Step 4 - Screens and Flows

```
FOR EACH SCREEN:
  NAME / PURPOSE
  LAYOUT: ASCII wireframe (keep it simple)
  STATES: empty, loading, success, error
  ACTIONS: what each control does

MAIN FLOW (numbered, 5-8 steps max):
  1. User opens app -> [first-run screen]
  2. ...
  N. User gets [result] -> [export / save]

FIRST-RUN: the user must reach a first win in under 60 seconds.
           Include a bundled sample file or demo mode.

DESIGN TOKENS: font, 2-3 colours, radius, spacing scale,
               light + dark palettes (hex values).
```

---

## Step 5 - License Key Approach

```
SIMPLE AND HONEST:
  - Gumroad can issue a license key per sale.
  - App ships with a free trial limit (e.g. N uses or 7 days) OR
    a watermark/export cap, then asks for the key.
  - Activation: app calls the Gumroad license verification
    endpoint (POST to api.gumroad.com/v2/licenses/verify with
    product_id and license_key). Confirm the current request
    format in Gumroad's API docs before implementing.
  - Cache validation locally so the app works offline afterwards.
  - Never embed secrets in the app. The product_id is not secret;
    API access tokens are, and must not ship.
  - Accept that piracy exists. Make buying easier than cracking.
```

---

## Step 6 - Build Plan

```
TASK LIST (ordered, each 1-4 hours, each independently verifiable):
  T1 Scaffold project, window, build runs
  T2 Core logic module + unit tests (no UI)
  T3 Main screen wired to core logic
  T4 Settings, persistence, error handling
  T5 First-run / sample data
  T6 Licensing + trial limits
  T7 Polish: icons, dark mode, shortcuts, about box
  ...

FOLDER STRUCTURE: [tree]
DEFINITION OF DONE: all MUST criteria pass, no console errors,
  installer runs on a clean machine.
```

---

## Output File: product_spec.md

```markdown
# Product Spec
Pipeline step: 2 of 6
Date: [date]

## Identity (name, tagline, platform, price)
## Scope (Must / Should / Cut + acceptance criteria)
## Tech Stack (choice, reason, pinned versions)
## Screens and Flows (wireframes, states, design tokens)
## Licensing
## Folder Structure
## Build Plan (T1...Tn)

## Pipeline Status
Step 1 DONE problem-scout   -> problem_report.md
Step 2 DONE mvp-architect   -> product_spec.md
Step 3 TODO app-builder     -> build_log.md
Step 4 TODO app-tester      -> test_report.md
Step 5 TODO app-packager    -> package_log.md
Step 6 TODO gumroad-launcher -> launch_kit.md
```

---

## Review Gate (MANDATORY)

After saving `product_spec.md`, present this EXACTLY:

```
Product spec complete. Saved to product_spec.md.

Summary:
- Product      : [name] - [tagline]
- Stack        : [stack]
- MUST features: [N]   Cut for later: [N]
- Build tasks  : [N] (est. [N] days)
- Price        : [$] one-time, license key

Review product_spec.md. You can:
  - Approve -> say "approved" or "build it"
  - Change scope -> say "cut [feature]" or "add [feature]"
  - Change stack -> say "use [stack] instead"

Waiting for approval before App Builder runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `build it`, `app builder`,
`proceed`, `next`, `go`, `looks good`
