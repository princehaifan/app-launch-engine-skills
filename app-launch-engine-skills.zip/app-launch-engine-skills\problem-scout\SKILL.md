---
name: problem-scout
description: >
  Step 1 of 6 in the App Launch Engine Pipeline. Finds a small, specific,
  painful problem that people already pay to solve, and validates it before
  anything is built. Researches communities, competitors, and pricing, scores
  5-8 candidate ideas on demand, competition, feasibility, and monetisation,
  then recommends exactly one. Output gates all downstream steps. Saves as
  problem_report.md.
---

# Problem Scout

Most products fail before the first line of code.
They solve a problem nobody has, or one nobody will pay for.
Your job is to find a small problem that hurts, that people already
spend money or time on, and that one desktop app can fix.
Decide. Do not hand back a menu.
Save as `problem_report.md`.

---

## The Core Constraint

```
ONE PROBLEM. ONE USER. ONE APP.
  A good first product fits in one sentence:
  "[Specific person] wastes [specific time/money] on [specific task];
   this app does it in [specific result]."
  If you need "and" twice, the idea is too big.

WHY DESKTOP:
  Desktop is right when the job involves local files, offline use,
  privacy (data must not leave the machine), batch processing,
  system integration, or a one-time purchase that people prefer to a
  subscription. If the idea works better as a website, say so and
  reject it.

WHAT TO AVOID:
  - Anything needing a server, accounts, or recurring infrastructure
  - Markets dominated by a free, good-enough tool
  - Problems the user cannot personally test
  - Regulated domains (medical, legal, financial advice)
```

---

## Step 1 - Hunt for Pain

```
WHERE PEOPLE COMPLAIN (search these, quote real posts):
  - Reddit: r/excel, r/photography, r/editors, r/freelance,
    r/datahoarder, r/Teachers, r/smallbusiness, niche-hobby subs
  - "Is there a tool that..." / "I wish there was an app to..."
  - "How do I bulk..." / "Why is there no way to..."
  - Gumroad, Product Hunt, Indie Hackers: what already sells?
  - Chrome/VS Code/Obsidian plugin reviews: 3-star reviews list gaps
  - Upwork/Fiverr gigs repeated weekly = automatable pain

PAIN SIGNALS (the more, the better):
  [ ] Same complaint appears in multiple threads
  [ ] People describe a manual workaround (spreadsheets, scripts)
  [ ] People say they would pay ("take my money")
  [ ] Existing tool is bloated, subscription-only, or ugly
  [ ] Problem recurs weekly, not once a year

Use WebSearch / the browser tools for real evidence.
Never invent quotes, numbers, or sources. If evidence is thin, say so.
```

---

## Step 2 - Build the Candidate List

```
LIST 5-8 CANDIDATES. For each:

  IDEA: [one-sentence product]
  CUSTOMER: [who exactly]
  PAIN: [what it costs them today]
  CURRENT FIX: [what they do now]
  EVIDENCE: [links / quotes / listings found]
  DESKTOP FIT: [why local app beats web]
```

---

## Step 3 - Score and Decide

```
SCORE EACH 1-5 (be harsh):

  DEMAND         - proof people want it and pay (weight x3)
  COMPETITION    - 5 = gap exists; 1 = crowded or free alternative (x2)
  FEASIBILITY    - can ONE person build an MVP in 1-2 weeks (x3)
  MONETISATION   - clear price point $9-$49, one-time purchase (x2)
  REACHABILITY   - can you find buyers without paid ads (x2)

  TOTAL = weighted sum (max 60)

RECOMMENDATION RULE:
  Pick the highest total. If top score < 36, say "no strong idea yet"
  and propose the next research angle instead of forcing a pick.
  Name the runner-up as a fallback.

PRICING ANALYSIS (for the winner):
  - 3 competitor prices found
  - Recommended launch price and why
  - Break-even: units needed to feel worth it
  - Note: marketplace fees and taxes change; verify current rates
    before quoting a net figure.
```

---

## Step 4 - Cheap Validation Plan

```
BEFORE BUILDING, DESIGN A 48-HOUR TEST:
  - Where to post the problem (not the product) and what to ask
  - A landing-page / waitlist or "pre-order at launch price" test
  - Success signal: e.g. 10+ replies or 5+ emails from target users
  - Kill signal: what result means pick the runner-up

Do NOT post or message anyone on the user's behalf. Draft the text
and let the user send it.
```

---

## Output File: problem_report.md

```markdown
# Problem Report
Pipeline step: 1 of 6
Date: [date]

## Winning Idea
One-liner: [sentence]
Customer: [who]
Pain: [cost today]
Why desktop: [reason]

## Evidence
[Links and quotes - real only]

## Candidates and Scores
| Idea | Demand | Comp. | Feasible | Money | Reach | Total |
|------|--------|-------|----------|-------|-------|-------|

## Competitor Snapshot
| Tool | Price | Weakness |
|------|-------|----------|

## Pricing Recommendation
[Price, rationale, break-even]

## Validation Plan
[48-hour test, success and kill signals, draft post text]

## Risks
[Top 3 and mitigations]

## Pipeline Status
Step 1 DONE problem-scout   -> problem_report.md
Step 2 TODO mvp-architect   -> product_spec.md
Step 3 TODO app-builder     -> build_log.md
Step 4 TODO app-tester      -> test_report.md
Step 5 TODO app-packager    -> package_log.md
Step 6 TODO gumroad-launcher -> launch_kit.md
```

---

## Review Gate (MANDATORY)

After saving `problem_report.md`, present this EXACTLY:

```
Problem report complete. Saved to problem_report.md.

Summary:
- Recommended product : [one-liner]
- Target customer     : [who]
- Launch price        : [$]
- Score               : [N]/60 (runner-up: [idea], [N]/60)
- Evidence strength   : [strong / moderate / thin]

Review problem_report.md. You can:
  - Approve -> say "approved" or "spec it"
  - Pick the runner-up -> say "use the runner-up"
  - Research more -> say "search [niche / community]"

Waiting for approval before MVP Architect runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `spec it`, `mvp architect`,
`proceed`, `next`, `go`, `looks good`
