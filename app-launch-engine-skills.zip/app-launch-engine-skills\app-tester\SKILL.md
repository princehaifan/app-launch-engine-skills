---
name: app-tester
description: >
  Step 4 of 6 in the App Launch Engine Pipeline. Takes build_log.md and
  tests the application for functionality, edge cases, usability, security,
  and performance. Includes a dependency audit, secrets scan, and a
  first-time-user walkthrough. All blocking issues must be fixed before
  packaging. Saves as test_report.md.
---

# App Tester

An app that passes its own tests is not the same as an app a stranger
can use. Test like a customer who paid $20 and is already annoyed.
Fix what fails. Do not ship what you would refund.
Save as `test_report.md`.

---

## The Five Checks

```
CHECK 1 - FUNCTIONAL:   every MUST acceptance criterion
CHECK 2 - EDGE CASES:   hostile inputs and bad environments
CHECK 3 - USABILITY:    first-time-user walkthrough
CHECK 4 - SECURITY:     secrets, dependencies, data handling
CHECK 5 - PERFORMANCE:  startup, memory, large inputs
```

---

## Check 1 - Functional

```
Re-run the test suite, then the MAIN FLOW from product_spec.md.
For each MUST feature record PASS / FAIL with evidence
(command output, screenshot path, or observed behaviour).
```

---

## Check 2 - Edge Cases

```
TRY, AND RECORD THE RESULT OF EACH:
  [ ] Empty input / zero files
  [ ] Huge input (10x expected size)
  [ ] Corrupt, locked, read-only, or deleted-mid-use file
  [ ] Path with spaces, unicode, very long names
  [ ] Duplicate names / overwrite prompts
  [ ] Cancel mid-operation: no half-written output left behind
  [ ] Double-click the launch icon twice
  [ ] Resize to minimum window; change DPI scaling
  [ ] No network: licensing and everything else behaves as spec'd
  [ ] Invalid, empty, and whitespace-padded license key
  [ ] Clock changed (trial limit sanity, not a security promise)

CRASH RULE: any unhandled exception or blank screen = BLOCKER.
```

---

## Check 3 - Usability Walkthrough

```
ROLE-PLAY A FIRST-TIME USER (read only the on-screen text):
  - Can they reach a result in under 60 seconds?
  - Is every error message actionable?
  - Any jargon, dead buttons, unlabeled icons?
  - Is the trial limit and how to buy clearly explained, without nagging?
Write down every moment of confusion. Each is a fix candidate.
```

---

## Check 4 - Security

```
  [ ] Secrets scan: grep the source and built package for tokens,
      keys, passwords, .env contents. Any hit = BLOCKER.
  [ ] Dependency audit: run the stack's audit tool
      (e.g. npm audit / pip-audit). Fix or justify high/critical.
  [ ] No remote code loaded at runtime; no eval of user data
  [ ] Electron only: contextIsolation on, nodeIntegration off,
      narrow preload API, CSP set, no remote module,
      external links open in the OS browser
  [ ] User data stored in the app-data folder, not install dir
  [ ] No telemetry unless disclosed in the spec
  [ ] Licence check does not send more than key + product id
  [ ] Third-party licences reviewed (can you redistribute them?)
```

---

## Check 5 - Performance

```
MEASURE, DON'T GUESS:
  - Cold start time (target < 3 s on a normal laptop)
  - Idle memory after 5 minutes
  - Processing time on a realistic large input
  - UI stays responsive during long work
Record numbers. Fix anything that feels slow before launch.
```

---

## Fix Loop

```
Classify each finding:
  BLOCKER  - crash, data loss, secret leak, core feature broken
  MAJOR    - confusing flow, bad error, notable bug
  MINOR    - cosmetic, nice-to-have

Fix all BLOCKERs and MAJORs, re-run affected checks, and record
the before/after. MINORs go to the v1.1 list.
```

---

## Output File: test_report.md

```markdown
# Test Report
Pipeline step: 4 of 6
Date: [date]

## Summary
Blockers: [N] fixed / [N] open
Major: [N] fixed / [N] open
Minor: [N] deferred

## Check Results
### Functional (table)
### Edge Cases (table)
### Usability notes
### Security (table + audit output summary)
### Performance (numbers)

## Fixes Applied
| Finding | Severity | Fix | Re-test |
|---------|----------|-----|---------|

## v1.1 Backlog
[minor items and cut features]

## Release Verdict
[SHIP / FIX FIRST] - one-sentence justification

## Pipeline Status
Step 1 DONE problem-scout   -> problem_report.md
Step 2 DONE mvp-architect   -> product_spec.md
Step 3 DONE app-builder     -> build_log.md
Step 4 DONE app-tester      -> test_report.md
Step 5 TODO app-packager    -> package_log.md
Step 6 TODO gumroad-launcher -> launch_kit.md
```

---

## Review Gate (MANDATORY)

After saving `test_report.md`, present this EXACTLY:

```
Testing complete. Saved to test_report.md.

Summary:
- Blockers : [N] open   Major: [N] open
- Security : [clean / issues noted]
- Cold start: [N] s     Verdict: [SHIP / FIX FIRST]

Review test_report.md. You can:
  - Approve -> say "approved" or "package it"
  - Fix more -> say "fix [item]"
  - Re-run a check -> say "re-test [check]"

Waiting for approval before App Packager runs.
```

**NEVER** proceed automatically. If the verdict is FIX FIRST, do not
offer "package it".

Approval keywords: `approved`, `package it`, `app packager`,
`proceed`, `next`, `go`, `looks good`
