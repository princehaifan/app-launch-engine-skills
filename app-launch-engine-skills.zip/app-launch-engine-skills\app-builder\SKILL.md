---
name: app-builder
description: >
  Step 3 of 6 in the App Launch Engine Pipeline. Implements the approved
  product_spec.md as a working desktop application, task by task, with the
  core logic separated from the UI, unit tests, persistence, licensing, and
  a polished interface. Verifies each task by running it before moving on.
  Saves progress as build_log.md.
---

# App Builder

Working code beats a beautiful plan.
Build the spec task by task. Run it after every task.
Do not add features the spec cut. Do not skip the polish the spec demands.
Save as `build_log.md`.

---

## The Core Constraint

```
BUILD ORDER:
  Logic first, UI second, polish third.
  Core logic lives in its own module with NO UI imports,
  so it can be tested without launching a window.

NEVER:
  - Add features from the CUT LIST
  - Hardcode secrets, tokens, or absolute paths
  - Write user data into the install directory
  - Claim something works without having run it
  - Add telemetry the spec did not approve
```

---

## Step 1 - Scaffold

```
1. Create the project in a dedicated folder named after the product.
2. Initialise with the stack in product_spec.md (pin versions).
3. Run the "hello window" build. If it does not open, fix before
   anything else.
4. Add: .gitignore, README (dev setup), LICENSE placeholder,
   scripts: dev, build, test, package.
5. Log: commands run and result.
```

---

## Step 2 - Implement Tasks T1...Tn

```
FOR EACH TASK IN product_spec.md:
  a. Re-read its acceptance criteria.
  b. Implement the smallest thing that satisfies them.
  c. Write or extend unit tests for logic (not for pixels).
  d. RUN: tests + launch the app + exercise the feature.
  e. Record in build_log.md: task, files touched, how verified,
     anything deviating from spec (and why).
  f. If blocked, pick the simplest workaround that keeps the
     acceptance criteria true. Note it. Do not stall.

CODE QUALITY:
  - Match the existing style; small functions; clear names
  - Errors are shown to the user in plain language with a next step
  - All file operations handle: missing file, permission denied,
    locked file, huge file, non-UTF-8 content, spaces/unicode in paths
  - Long operations show progress and can be cancelled
```

---

## Step 3 - Interface Polish

```
CHECKLIST (do not skip - this is what makes it sellable):
  [ ] Consistent spacing, type scale, and colour tokens from the spec
  [ ] Light and dark mode both look intentional
  [ ] Empty states explain what to do (not blank panels)
  [ ] Drag-and-drop where files are involved
  [ ] Keyboard shortcuts for main actions, shown in tooltips
  [ ] Window remembers size and position
  [ ] Respects system DPI scaling
  [ ] App icon (multiple sizes), proper window title, About dialog
  [ ] First-run reaches a result in under 60 seconds
  [ ] No lorem ipsum, no debug text, no console errors

For visual work, take screenshots and review them. Use the
frontend-design skill's principles for layout and typography.
```

---

## Step 4 - Licensing and Trial

```
IMPLEMENT AS SPECIFIED:
  - Trial limit enforced in one place (a single function)
  - "Enter license key" dialog -> verify against Gumroad's
    license endpoint -> cache result locally
  - Offline grace: previously validated keys keep working
  - Clear messages: invalid key, refunded/disabled key, no network
  - NO API tokens in the shipped code; only the public product id
Test with an obviously fake key and with the network off.
```

---

## Step 5 - Self-Check Before Handoff

```
RUN:
  - Full test suite: all pass
  - Production build: completes with no warnings that matter
  - Launch the built app from a clean working directory
  - Walk the MAIN FLOW from product_spec.md end to end
  - Confirm every MUST acceptance criterion: PASS / FAIL

Report FAIL honestly. Do not hide unfinished items.
```

---

## Output File: build_log.md

```markdown
# Build Log
Pipeline step: 3 of 6
Date: [date]

## Project Location
[path]   Stack: [versions]   Run: [dev command]   Build: [build command]

## Task Log
| Task | Status | Files | How verified | Deviations |
|------|--------|-------|--------------|------------|

## MUST Feature Status
| Feature | Acceptance criterion | Result |
|---------|----------------------|--------|

## Known Issues
[list, with severity]

## Not Done / Deferred
[list]

## Pipeline Status
Step 1 DONE problem-scout   -> problem_report.md
Step 2 DONE mvp-architect   -> product_spec.md
Step 3 DONE app-builder     -> build_log.md
Step 4 TODO app-tester      -> test_report.md
Step 5 TODO app-packager    -> package_log.md
Step 6 TODO gumroad-launcher -> launch_kit.md
```

---

## Review Gate (MANDATORY)

After saving `build_log.md`, present this EXACTLY:

```
Build complete. Saved to build_log.md.

Summary:
- App          : [name] at [path]
- Tasks done   : [N]/[N]
- MUST features: [N] pass, [N] fail
- Tests        : [N] passing
- Known issues : [N]

Try it: [exact command to launch]

Review the app. You can:
  - Approve -> say "approved" or "test it"
  - Request changes -> say "change [thing]"
  - Report a bug -> describe what you saw

Waiting for approval before App Tester runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `test it`, `app tester`,
`proceed`, `next`, `go`, `looks good`
