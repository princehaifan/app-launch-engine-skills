---
name: gumroad-launcher
description: >
  Step 6 of 6 in the App Launch Engine Pipeline. Prepares everything
  needed to sell the packaged app on Gumroad: product name and branding,
  store-page copy, pricing, screenshot and cover specs, license-key setup,
  installation guide, launch posts, a support playbook, and a post-launch
  improvement loop. Clearly separates work done from steps that need the
  user's account. Saves as launch_kit.md.
---

# Gumroad Launcher

Building the product was half the job.
A listing that does not explain the pain, show the result, and make
buying feel safe will not convert, however good the app is.
Prepare the complete launch kit. Then hand the account-bound steps
to the user, clearly marked.
Save as `launch_kit.md`.

---

## The Core Constraint

```
WHAT YOU DO vs WHAT THE USER DOES:
  YOU: write copy, specs, guides, posts, support macros;
       generate screenshots/cover from the running app;
       prepare the upload bundle.
  USER ONLY: create the Gumroad account, enter payout and tax
       details, set the price and publish the product, upload files,
       post on social/communities, reply to customers.
  Never publish, post, or message anyone on the user's behalf
  without their explicit go-ahead for that specific action.

HONESTY RULE:
  No fake reviews, fake testimonials, fake download counts, fake
  scarcity, or income claims. Claim only what the app does and
  has been tested to do.
```

---

## Step 1 - Brand Basics

```
FROM product_spec.md CONFIRM:
  Name, tagline, price, platform.
  Gumroad URL slug (short, lowercase).
  Colour/typography from the design tokens, reused on every asset.
  Logo/wordmark: simple, legible at 128px.
```

---

## Step 2 - Store Page Copy

```
WRITE (plain, specific, no hype):

  TITLE: [Name] - [result in 6-8 words]

  OPENER (2 lines): the pain, in the customer's own words
    (reuse real phrases found in problem_report.md).

  WHAT IT DOES: 4-6 bullets, each = feature -> benefit.

  HOW IT WORKS: 3 steps with a screenshot each.

  WHO IT'S FOR / NOT FOR: honest. Saying "not for X" builds trust.

  WHAT YOU GET: installer, license key, free updates for [period],
    support email, version number.

  REQUIREMENTS: Windows version, disk space, offline or online.

  GUARANTEE: state the refund policy you actually intend to honour.

  FAQ: install warning (SmartScreen), license activation, how many
    machines, updates, refunds, privacy (no data leaves the PC).

  CTA: one clear button label ("Get [Name] - $X").
```

---

## Step 3 - Visual Assets

```
PRODUCE FROM THE REAL, RUNNING APP:
  Cover image: Gumroad shows it large; design for a wide crop.
  Thumbnail: square, readable at small size.
  5-7 screenshots: main flow in order, then dark mode, then a
    before/after of the result. Add short captions.
  15-30s demo GIF or video of the core flow (screen recording).
Use the image/design skills if helpful. Save to launch/assets/
with the exact pixel sizes noted. Check Gumroad's current
recommended dimensions before finalising.
```

---

## Step 4 - Pricing and Product Settings

```
RECOMMEND (user enters these):
  Price: from problem_report.md, with one launch discount idea
    (e.g. first 14 days -20% via discount code) rather than a
    permanently "pay what you want" price.
  License keys: ENABLE (the app verifies them; see product_spec.md).
  Files: upload release/[AppName]-1.0.0.zip.
  Receipt/post-purchase message: install steps, license key
    location, support email.
  Refund window and tax handling: user checks Gumroad's current
  settings and fee schedule; quote no fee percentages from memory.
```

---

## Step 5 - Launch Content

```
DRAFT (for the user to review and post themselves):
  1. Launch post for the community where the pain was found
     (problem-first, product second, follows that community's rules;
     check self-promotion rules before posting).
  2. Short X/LinkedIn thread: problem -> 3 screenshots -> link.
  3. Email to anyone who joined the validation waitlist.
  4. Product Hunt / Indie Hackers / relevant directory blurbs.
  5. 30-60s demo video script.
  6. Pinned reply template for questions.

LAUNCH CHECKLIST:
  [ ] Test purchase end to end (use a 100% discount code):
      receive email, download, install, activate key
  [ ] Store page proofread, links work, support email monitored
  [ ] Analytics: Gumroad stats only (no tracking in the app)
  [ ] Launch day plan: where to post, in what order, at what time
```

---

## Step 6 - Support Playbook

```
CANNED REPLIES (plain, friendly, specific):
  - Windows blocked the installer (SmartScreen steps)
  - License key not accepted
  - Lost license key / new computer
  - Refund request (honour per stated policy)
  - Bug report (ask: version, steps, screenshot, log file location)
  - Feature request (log it, do not promise dates)

TRIAGE: bug -> fix list; request -> v1.1 backlog; refund -> process
quickly and ask why (it is research).
```

---

## Step 7 - Improve Loop

```
AFTER LAUNCH, EVERY WEEK:
  Track: views -> sales conversion, refund reasons, support themes.
  Decide: fix bug / clarify page / add feature / stop.
  Ship v1.0.1 for bugs fast; batch features into v1.1.
  Rule: build the next feature only after 3 customers ask for it.
  If conversion < 1% on 200+ views: fix the page before the app.
  If no sales after a fair test: run problem-scout again with what
  you learned; the runner-up may be the real winner.
```

---

## Output File: launch_kit.md

```markdown
# Launch Kit
Pipeline step: 6 of 6
Date: [date]

## Product Basics (name, tagline, price, slug)
## Store Page Copy (ready to paste)
## Visual Assets (file list + sizes)
## Gumroad Settings Checklist (user enters)
## Launch Content (all drafts)
## Launch Checklist
## Support Playbook
## Weekly Improve Loop

## Done By Me vs Needs You
| Task | Status | Owner |
|------|--------|-------|

## Pipeline Status
Step 1 DONE problem-scout    -> problem_report.md
Step 2 DONE mvp-architect    -> product_spec.md
Step 3 DONE app-builder      -> build_log.md
Step 4 DONE app-tester       -> test_report.md
Step 5 DONE app-packager     -> package_log.md
Step 6 DONE gumroad-launcher -> launch_kit.md
```

---

## Review Gate (MANDATORY)

After saving `launch_kit.md`, present this EXACTLY:

```
Launch kit complete. Saved to launch_kit.md.

Summary:
- Product     : [name] at $[price]
- Page copy   : ready to paste
- Assets      : [N] files in launch/assets/
- Posts drafted: [N]
- Support macros: [N]

Needs you (I cannot do these):
  1. Create/verify your Gumroad account and payout details
  2. Create the product and paste the copy
  3. Upload release/[AppName]-1.0.0.zip and enable license keys
  4. Run a 100% discount test purchase
  5. Publish, then post the launch content yourself

Review launch_kit.md. You can:
  - Approve -> say "approved"
  - Tighten copy -> say "rewrite the store page"
  - Different price -> say "price it at [$]"

Pipeline complete after your approval. Re-run problem-scout
when you want the next product.
```

**NEVER** publish or post anything automatically.

Approval keywords: `approved`, `done`, `looks good`, `ship it`
