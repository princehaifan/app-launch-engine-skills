---
name: app-packager
description: >
  Step 5 of 6 in the App Launch Engine Pipeline. Turns the tested app into
  a distributable product: Windows installer (and optional portable zip),
  versioning, checksums, code-signing guidance, SmartScreen handling, a
  clean-machine install test, and the delivery bundle that will be uploaded
  to Gumroad. Saves as package_log.md.
---

# App Packager

Buyers judge the product at the moment they double-click the installer.
A scary Windows warning, a missing icon, or an install that fails on
a clean machine produces refunds and chargebacks.
Package it so the first five minutes feel trustworthy.
Save as `package_log.md`.

---

## The Core Constraint

```
THE CLEAN-MACHINE RULE:
  An installer is not done until it has been installed, run, and
  uninstalled on a machine (or fresh Windows Sandbox / VM) that has
  never seen the dev environment. "Works on my machine" is a fail.

SECRETS RULE:
  Signing certificates and passwords never enter the repo, the log,
  or the chat. They live in environment variables or the user's
  own certificate store. If signing needs credentials, the USER
  runs that step.
```

---

## Step 1 - Release Metadata

```
SET AND RECORD:
  Product name / publisher name / app id (reverse-domain)
  Version: 1.0.0 (semantic versioning; bump before every release)
  Icon: .ico with 16-256px sizes (installer + app + tray)
  Copyright line, support email, website/Gumroad URL
  Licence: EULA text shown in installer (short, plain language,
    includes refund/support terms consistent with the store page)
```

---

## Step 2 - Build the Installer

```
FOLLOW THE STACK IN product_spec.md:
  Electron : electron-builder -> NSIS .exe (per-user install avoids
             admin prompts), optional portable target
  Tauri    : tauri build -> NSIS/MSI
  Python   : PyInstaller (one-folder is more reliable than one-file)
             + Inno Setup or NSIS for the installer

INSTALLER CHECKLIST:
  [ ] Start Menu shortcut; optional desktop shortcut
  [ ] Clean uninstall (leaves user data only if user chose to)
  [ ] Installer and app show correct name, version, icon, publisher
  [ ] Upgrade-in-place keeps settings and license
  [ ] File size noted; unused dependencies stripped
  [ ] Build is reproducible from a documented command
```

---

## Step 3 - Trust: Signing and SmartScreen

```
THE HARD TRUTH:
  Unsigned Windows installers trigger "Windows protected your PC"
  (SmartScreen). Some buyers will bail. Options, cheapest first:

  A) Ship unsigned at launch and PREPARE THE BUYER:
     include a one-image guide: "More info -> Run anyway", and a
     note on the store page. Honest, free, some friction.
  B) Sign with a standard code-signing certificate: removes the
     "unknown publisher" label but SmartScreen reputation still
     builds over time.
  C) Cloud/managed signing services: lower upfront effort,
     recurring cost.
  Pricing and eligibility change; check current terms before
  recommending one. Recommend A for validation, B/C once sales
  justify the cost.

  Also: submit the final exe to Microsoft's Defender false-positive
  portal if flagged, and scan it with a multi-engine scanner
  before upload to catch packer false positives early.
```

---

## Step 4 - Clean-Machine Test

```
IN WINDOWS SANDBOX / A FRESH VM:
  1. Copy only the installer in
  2. Install; note every prompt and warning
  3. Launch; reach first result using the sample data
  4. Enter a real test license key and a bad one
  5. Close, reopen: settings persist
  6. Uninstall: shortcuts and files removed
Record each step PASS/FAIL. Any FAIL = fix and rebuild.
```

---

## Step 5 - Delivery Bundle

```
BUILD release/ CONTAINING:
  [AppName]-Setup-1.0.0.exe
  [AppName]-1.0.0-portable.zip        (if built)
  README.txt        (install, first steps, SmartScreen note, support)
  LICENSE.txt / EULA.txt
  CHANGELOG.txt
  SHA256SUMS.txt    (checksums for every file)

Zip the bundle as [AppName]-1.0.0.zip for Gumroad upload.
Record sizes and checksums in package_log.md.
Do NOT upload anything yourself; the user uploads in Step 6.
```

---

## Output File: package_log.md

```markdown
# Package Log
Pipeline step: 5 of 6
Date: [date]

## Release
Name / Version / Publisher / App id

## Artifacts
| File | Size | SHA-256 |
|------|------|---------|

## Build Commands
[exact reproducible commands]

## Signing Decision
[A/B/C, rationale, buyer-facing mitigation]

## Clean-Machine Test
| Step | Result | Notes |
|------|--------|-------|

## Delivery Bundle Contents
[tree]

## Pipeline Status
Step 1 DONE problem-scout   -> problem_report.md
Step 2 DONE mvp-architect   -> product_spec.md
Step 3 DONE app-builder     -> build_log.md
Step 4 DONE app-tester      -> test_report.md
Step 5 DONE app-packager    -> package_log.md
Step 6 TODO gumroad-launcher -> launch_kit.md
```

---

## Review Gate (MANDATORY)

After saving `package_log.md`, present this EXACTLY:

```
Packaging complete. Saved to package_log.md.

Summary:
- Version     : [1.0.0]
- Installer   : [file] ([N] MB)
- Signed      : [yes / no - buyer guide included]
- Clean-machine test: [N]/[N] steps pass
- Bundle      : release/[AppName]-1.0.0.zip

Review package_log.md. You can:
  - Approve -> say "approved" or "launch it"
  - Change signing plan -> say "sign it" / "stay unsigned"
  - Rebuild -> say "rebuild after [change]"

Waiting for approval before Gumroad Launcher runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `launch it`, `gumroad launcher`,
`proceed`, `next`, `go`, `looks good`
